# Simple Raid Frames

## [v1.5](https://github.com/ZapaNOR/SimpleRaidFrames/tree/v1.5) (2026-02-01)
[Full Changelog](https://github.com/ZapaNOR/SimpleRaidFrames/compare/v1.0...v1.5) 

- Clean and split code for readability and maintainability, option to hide player from 5-man group, hide "Party" text above 5-man group  
