# Simple Raid Frames

## [v1.6](https://github.com/ZapaNOR/SimpleRaidFrames/tree/v1.6) (2026-02-01)
[Full Changelog](https://github.com/ZapaNOR/SimpleRaidFrames/compare/v1.5...v1.6) 

- Hide player in 5-man, Show player when not in group, custom width for party frames (with some bugs)  
