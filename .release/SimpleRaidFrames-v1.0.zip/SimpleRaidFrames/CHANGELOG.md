# Simple Raid Frames

## [v1.0](https://github.com/ZapaNOR/SimpleRaidFrames/tree/v1.0) (2026-01-31)
[Full Changelog](https://github.com/ZapaNOR/SimpleRaidFrames/commits/v1.0) 

- Prepare for first release  
- Initial commit  
